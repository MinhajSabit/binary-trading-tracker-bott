
# Binary Trading Tracker 🤖

A simple Telegram bot for tracking binary trading sessions.

## How to Deploy
- Install requirements: `pip install -r requirements.txt`
- Run: `python bot.py`
